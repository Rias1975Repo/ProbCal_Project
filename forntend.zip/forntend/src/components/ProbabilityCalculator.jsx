import { useMemo, useState } from "react";
import { calculateProbability } from "../api/probabilityApi";

export default function ProbabilityCalculator() {
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [operation, setOperation] = useState("CombinedWith");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const validationMessage = useMemo(() => {
    if (a === "" || b === "") return "Both probabilities are required.";
    const av = Number(a), bv = Number(b);
    if (Number.isNaN(av) || Number.isNaN(bv)) return "Inputs must be numbers.";
    if (av < 0 || av > 1 || bv < 0 || bv > 1) return "Values must be between 0 and 1.";
    return "";
  }, [a, b]);

  const canCalculate = validationMessage === "" && !loading;

  async function onCalculate() {
    setError("");
    setResult(null);
    setLoading(true);

    try {
      const data = await calculateProbability({
        a: Number(a),
        b: Number(b),
        operation
      });
      setResult(data.result);
    } catch (e) {
      setError(e.message || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <header style={styles.header}>
          <h2 style={styles.title}>Probability Calculator</h2>
          <p style={styles.subtitle}>Enter independent variables to compute outcomes</p>
        </header>

        <div style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Probability A</label>
            <input 
              type="number" 
              step="0.01"
              placeholder="0.5"
              style={styles.input} 
              value={a} 
              onChange={e => setA(e.target.value)} 
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Probability B</label>
            <input 
              type="number" 
              step="0.01"
              placeholder="0.5"
              style={styles.input} 
              value={b} 
              onChange={e => setB(e.target.value)} 
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Operation</label>
            <select 
              style={styles.select} 
              value={operation} 
              onChange={e => setOperation(e.target.value)}
            >
              <option value="CombinedWith">Combined With (A AND B)</option>
              <option value="Either">Either (A OR B)</option>
            </select>
          </div>

          {!canCalculate && a !== "" && b !== "" && (
            <div style={styles.errorBanner}>{validationMessage}</div>
          )}

          <button 
            disabled={!canCalculate} 
            onClick={onCalculate}
            style={{
              ...styles.button,
              ...(canCalculate ? {} : styles.buttonDisabled)
            }}
          >
            {loading ? "Calculating..." : "Calculate Result"}
          </button>
        </div>

        {error && <div style={styles.errorBox}>⚠️ {error}</div>}

        {result !== null && (
          <div style={styles.resultContainer}>
            <span style={styles.resultLabel}>Calculated Probability</span>
            <div style={styles.resultValue}>{(result * 100).toFixed(2)}%</div>
            <small style={styles.resultRaw}>Raw value: {result}</small>
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    minHeight: "100vh",
    backgroundColor: "#f4f7f6",
    fontFamily: "'Inter', system-ui, sans-serif",
    padding: "20px",
  },
  card: {
    backgroundColor: "#ffffff",
    padding: "32px",
    borderRadius: "16px",
    boxShadow: "0 10px 25px rgba(0,0,0,0.05)",
    width: "100%",
    maxWidth: "420px",
  },
  header: {
    textAlign: "center",
    marginBottom: "24px",
  },
  title: {
    margin: "0 0 8px 0",
    color: "#1a202c",
    fontSize: "24px",
    fontWeight: "700",
  },
  subtitle: {
    margin: 0,
    color: "#718096",
    fontSize: "14px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  inputGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
  },
  label: {
    fontSize: "14px",
    fontWeight: "600",
    color: "#4a5568",
  },
  input: {
    padding: "12px",
    borderRadius: "8px",
    border: "1px solid #e2e8f0",
    fontSize: "16px",
    outline: "none",
    transition: "border-color 0.2s",
  },
  select: {
    padding: "12px",
    borderRadius: "8px",
    border: "1px solid #e2e8f0",
    backgroundColor: "white",
    fontSize: "16px",
    cursor: "pointer",
  },
  button: {
    padding: "14px",
    borderRadius: "8px",
    border: "none",
    backgroundColor: "#4f46e5",
    color: "white",
    fontSize: "16px",
    fontWeight: "600",
    cursor: "pointer",
    marginTop: "8px",
    transition: "background-color 0.2s",
  },
  buttonDisabled: {
    backgroundColor: "#a5a2f3",
    cursor: "not-allowed",
  },
  errorBanner: {
    fontSize: "12px",
    color: "#e53e3e",
    textAlign: "center",
  },
  errorBox: {
    marginTop: "16px",
    padding: "12px",
    backgroundColor: "#fff5f5",
    color: "#c53030",
    borderRadius: "8px",
    fontSize: "14px",
    border: "1px solid #feb2b2",
  },
  resultContainer: {
    marginTop: "24px",
    padding: "20px",
    backgroundColor: "#f0fdf4",
    borderRadius: "12px",
    textAlign: "center",
    border: "1px solid #bbf7d0",
  },
  resultLabel: {
    display: "block",
    fontSize: "12px",
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    color: "#166534",
    marginBottom: "4px",
  },
  resultValue: {
    fontSize: "32px",
    fontWeight: "800",
    color: "#15803d",
  },
  resultRaw: {
    color: "#16a34a",
    fontSize: "12px",
  }
};