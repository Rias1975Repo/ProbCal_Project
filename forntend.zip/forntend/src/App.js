import ProbabilityCalculator from "./components/ProbabilityCalculator";

function App() {
  return <ProbabilityCalculator />;
}

export default App;
