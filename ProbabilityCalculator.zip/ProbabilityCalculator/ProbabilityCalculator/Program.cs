﻿using ProbabilityCalculator.Logging;
using ProbabilityCalculator.Products;
using ProbabilityCalculator.Logging;

var builder = WebApplication.CreateBuilder(args);

// ILogger: Console + Text file
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.AddProvider(new FileLoggerProvider("logs/probability-log.txt"));

// CORS for Vite dev server
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:3000")
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Factory registrations (REFERENCE STYLE)
ProbabilityOperationFactory.Register("CombinedWith", typeof(CombinedWithOperation));
ProbabilityOperationFactory.Register("Either", typeof(EitherOperation));

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("AllowFrontend");

app.MapControllers();

app.Run();
