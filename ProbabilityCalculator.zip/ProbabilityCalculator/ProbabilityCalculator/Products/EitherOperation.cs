﻿namespace ProbabilityCalculator.Products;

public sealed class EitherOperation : IProbabilityOperation
{
    public decimal Execute(decimal a, decimal b) => a + b - (a * b);
}
