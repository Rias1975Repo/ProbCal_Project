﻿namespace ProbabilityCalculator.Products;

public interface IProbabilityOperation
{
    decimal Execute(decimal a, decimal b);
}
