﻿namespace ProbabilityCalculator.Products;

public sealed class CombinedWithOperation : IProbabilityOperation
{
    public decimal Execute(decimal a, decimal b) => a * b;
}
