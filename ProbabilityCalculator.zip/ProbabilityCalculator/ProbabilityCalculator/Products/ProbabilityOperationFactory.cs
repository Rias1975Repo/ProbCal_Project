﻿namespace ProbabilityCalculator.Products;

public static class ProbabilityOperationFactory
{
    private static readonly Dictionary<string, Type> _registered = new(StringComparer.OrdinalIgnoreCase);

    public static void Register(string operationKey, Type operationType)
    {
        if (!typeof(IProbabilityOperation).IsAssignableFrom(operationType))
            throw new ArgumentException("Type must implement IProbabilityOperation.");

        _registered[operationKey] = operationType;
    }

    public static IProbabilityOperation Create(string operationKey)
    {
        if (string.IsNullOrWhiteSpace(operationKey))
            throw new ArgumentException("Operation is required.");

        if (!_registered.TryGetValue(operationKey, out var type))
            throw new ArgumentException($"Operation '{operationKey}' is not registered.");

        return (IProbabilityOperation)Activator.CreateInstance(type)!;
    }
}
