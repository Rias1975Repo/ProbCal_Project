﻿using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace ProbabilityCalculator.Logging;

public sealed class FileLoggerProvider : ILoggerProvider
{
    private readonly BlockingCollection<string> _queue = new();
    private readonly string _filePath;

    public FileLoggerProvider(string filePath)
    {
        _filePath = filePath;
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);

        Task.Run(async () =>
        {
            foreach (var msg in _queue.GetConsumingEnumerable())
            {
                await File.AppendAllTextAsync(_filePath, msg + Environment.NewLine);
            }
        });
    }

    public ILogger CreateLogger(string categoryName)
        => new FileLogger(_queue, categoryName);

    public void Dispose() => _queue.CompleteAdding();

    private sealed class FileLogger : ILogger
    {
        private readonly BlockingCollection<string> _queue;
        private readonly string _category;

        public FileLogger(BlockingCollection<string> queue, string category)
        {
            _queue = queue;
            _category = category;
        }

        public IDisposable BeginScope<TState>(TState state) => null!;
        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

        public void Log<TState>(LogLevel logLevel, EventId eventId,
            TState state, Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            var line =
                $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {logLevel} | {_category} | {formatter(state, exception)}";

            _queue.Add(line);
        }
    }
}
