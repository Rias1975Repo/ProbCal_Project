﻿using Microsoft.AspNetCore.Mvc;
using ProbabilityCalculator.Models;
using ProbabilityCalculator.Products;

namespace ProbabilityCalculator.Api.Controllers;

[ApiController]
[Route("api/probability")]
public sealed class ProbabilityController : ControllerBase
{
    private readonly ILogger<ProbabilityController> _logger;

    public ProbabilityController(ILogger<ProbabilityController> logger)
    {
        _logger = logger;
    }

    [HttpPost("calculate")]
    public ActionResult<CalculationResponse> Calculate([FromBody] CalculationRequest request)
    {
        try
        {
            // Minimal backend guard (frontend handles validation fully)
            if (request.A is < 0m or > 1m || request.B is < 0m or > 1m)
                return BadRequest(new { error = "Probabilities must be between 0 and 1." });

            if (string.IsNullOrWhiteSpace(request.Operation))
                return BadRequest(new { error = "Operation is required." });

            var op = ProbabilityOperationFactory.Create(request.Operation);
            var result = op.Execute(request.A, request.B);

            _logger.LogInformation(
                "Date={Date} Operation={Operation} A={A} B={B} Result={Result}",
                DateTimeOffset.Now, request.Operation, request.A, request.B, result
            );

            return Ok(new CalculationResponse(result));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error in probability calculation.");
            return StatusCode(500, new { error = "Internal server error." });
        }
    }
}
