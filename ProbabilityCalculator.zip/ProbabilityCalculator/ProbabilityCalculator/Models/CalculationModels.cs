﻿namespace ProbabilityCalculator.Models;

public sealed record CalculationRequest(
    decimal A,
    decimal B,
    string Operation   // "CombinedWith" | "Either"
);

public sealed record CalculationResponse(decimal Result);
